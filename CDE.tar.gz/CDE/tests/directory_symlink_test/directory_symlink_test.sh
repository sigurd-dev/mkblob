#!/bin/sh
cat ~/CDE/tests/fake-root-dir/usr/lib/gcc/i486-linux-gnu/4.4.1/infile.txt
