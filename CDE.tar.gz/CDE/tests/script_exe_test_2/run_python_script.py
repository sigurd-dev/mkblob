#!/usr/bin/env python

import numpy
x = numpy.array([1,2,3])
print x

