#!/bin/sh

uname -r

