#!/bin/sh
ls gcc-dir-symlink > /dev/null # don't worry about stdout
